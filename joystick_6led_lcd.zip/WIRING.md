# Wiring / Pin mapping (BCM numbering)

## MCP3008 <-> Raspberry Pi
- MCP3008 VDD (pin16)  -> Pi 3.3V
- MCP3008 VREF (pin15) -> Pi 3.3V
- MCP3008 AGND (pin14) -> Pi GND
- MCP3008 DGND (pin9)  -> Pi GND
- MCP3008 CLK  (pin13) -> Pi SCLK (BCM 11)
- MCP3008 DOUT (pin12) -> Pi MISO (BCM 9)
- MCP3008 DIN  (pin11) -> Pi MOSI (BCM 10)
- MCP3008 CS   (pin10) -> BCM 22 (manual CS) OR CE0 (BCM 8) if using hardware CS

## Joystick
- Joystick VRx (wiper) -> MCP3008 CH0
- Joystick VRy (wiper) -> MCP3008 CH1
- Joystick Vcc -> 3.3V
- Joystick GND -> GND
- Joystick switch -> BCM 12 (use internal pull-up in code)

## LEDs (each LED anode -> GPIO through 220Ω resistor -> cathode -> GND)
- LED_RED    -> BCM 17  (locked indicator)
- LED_GREEN  -> BCM 18  (unlocked indicator)
- LED_UP     -> BCM 5
- LED_DOWN   -> BCM 6
- LED_LEFT   -> BCM 13
- LED_RIGHT  -> BCM 19

## I2C LCD (optional)
- SDA -> BCM 2 (SDA)
- SCL -> BCM 3 (SCL)
- VCC -> 5V or 3.3V depending on module (prefer 3.3V if the backpack supports it)
- GND -> GND
- Use `i2cdetect -y 1` to confirm the I2C address (commonly 0x27 or 0x3f)

## ASCII Schematic (simplified)
```
Pi 3.3V -----+----------------> MCP3008 VDD, VREF
GND   -------+----------------> MCP3008 AGND, DGND
BCM11 (SCLK) ---> MCP3008 CLK
BCM10 (MOSI) ---> MCP3008 DIN
BCM9  (MISO) ---> MCP3008 DOUT
BCM22 (CS)   ---> MCP3008 CS   (or CE0 / BCM8)
CH0 <--- Joystick VRx
CH1 <--- Joystick VRy
BCM12 <--- Joystick SW (pull-up)
LEDs -> BCM17,18,5,6,13,19 (via resistors)
I2C LCD -> BCM2 (SDA), BCM3 (SCL)
```
