#!/bin/bash
# Simple run script
sudo python3 src/joystick_6led_mcp3008_lcd.py
