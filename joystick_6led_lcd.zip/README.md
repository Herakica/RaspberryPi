# Joystick → 6 LEDs + 16x2 I2C LCD (MCP3008 + Raspberry Pi)

This repository contains a complete, ready-to-commit project that reads a joystick (2 potentiometers + push switch)
through an MCP3008 ADC and lights LEDs indicating direction (up/down/left/right). A red/green LED pair shows locked/unlocked
state toggled by pressing the joystick. A 16×2 I²C LCD displays X/Y values and lock status in real time.

## Contents
- `src/joystick_6led_mcp3008_lcd.py` — main script (Python 3). Supports optional 16x2 I2C LCD.
- `requirements.txt` — pip dependencies.
- `WIRING.md` — wiring, pin mapping and ASCII schematic.
- `LICENSE` — MIT license.
- `README.md` — this file (human readable).
- `run.sh` — simple script to run the program (with sudo).

## Quick start
1. Enable SPI and I2C on the Raspberry Pi: `sudo raspi-config` → Interface Options → enable SPI and I2C.
2. Install dependencies:
   ```bash
   sudo apt update
   sudo apt install -y python3-pip python3-rpi.gpio i2c-tools
   pip3 install -r requirements.txt
   ```
3. Wire the MCP3008, joystick, LEDs and optional I2C LCD per `WIRING.md`.
4. Run the program with:
   ```bash
   sudo python3 src/joystick_6led_mcp3008_lcd.py
   ```
   (sudo ensures access to SPI / GPIO)

## Notes
- The LCD is optional. If the `RPLCD` or `smbus2` libraries are missing, the script will still run but without the LCD display.
- Default I2C address for the LCD is `0x27`. Use `i2cdetect -y 1` to verify the address on your Pi.
- The script includes an optional manual CS (GPIO 22) or you can use hardware CE0 (BCM 8). See the config constants in the script.
