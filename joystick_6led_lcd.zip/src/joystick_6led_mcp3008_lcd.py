#!/usr/bin/env python3
"""joystick_6led_mcp3008_lcd.py

Full version: MCP3008 + Joystick + 6 LEDs + optional 16x2 I2C LCD.
- If RPLCD/smbus2 are installed and an I2C LCD is present, the script will display X/Y and lock status.
- If not present, the program continues without LCD functionality.

Run with: sudo python3 joystick_6led_mcp3008_lcd.py
"""

import time
import spidev
import RPi.GPIO as GPIO

# Try to import LCD libs; if unavailable, continue without LCD.
has_lcd = False
try:
    from RPLCD.i2c import CharLCD
    has_lcd = True
except Exception:
    has_lcd = False

# ---------------------
# Configuration / Pins
# ---------------------
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# LED pins
LED_RED = 17
LED_GREEN = 18
LED_UP = 5
LED_DOWN = 6
LED_LEFT = 13
LED_RIGHT = 19
ALL_DIR_LEDS = [LED_UP, LED_DOWN, LED_LEFT, LED_RIGHT]

# Switch (joystick press)
SW_PIN = 12
GPIO.setup(SW_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)

# Setup LEDs
GPIO.setup(LED_RED, GPIO.OUT, initial=GPIO.HIGH)
GPIO.setup(LED_GREEN, GPIO.OUT, initial=GPIO.LOW)
for led in ALL_DIR_LEDS:
    GPIO.setup(led, GPIO.OUT, initial=GPIO.LOW)

# SPI / MCP3008
SPI_BUS = 0
SPI_DEVICE = 0
spi = spidev.SpiDev()
spi.open(SPI_BUS, SPI_DEVICE)
spi.max_speed_hz = 1_000_000
spi.no_cs = True  # we'll toggle manual CS by default

MANUAL_CS = True
CS_PIN = 22
if MANUAL_CS:
    GPIO.setup(CS_PIN, GPIO.OUT, initial=GPIO.HIGH)

# Thresholds
CENTER_LOW = 480
CENTER_HIGH = 544

# Debounce/timing
DEBOUNCE_DELAY = 0.05
LOOP_DELAY = 0.05

# LCD config (optional)
LCD_I2C_ADDR = 0x27  # common; verify with i2cdetect
LCD_PORT = 1
lcd = None
if has_lcd:
    try:
        lcd = CharLCD(i2c_expander='PCF8574', address=LCD_I2C_ADDR, port=LCD_PORT,
                      cols=16, rows=2, dotsize=8)
        lcd.write_string('Joystick init...')
        time.sleep(0.5)
        lcd.clear()
    except Exception as e:
        print('LCD init failed:', e)
        lcd = None
        has_lcd = False

# State
unlocked = False

def _select_cs(low=True):
    if not MANUAL_CS:
        return
    GPIO.output(CS_PIN, GPIO.LOW if low else GPIO.HIGH)

def read_mcp3008_channel(channel: int) -> int:
    if channel < 0 or channel > 7:
        raise ValueError('MCP3008 channel must be 0-7')
    _select_cs(low=True)
    adc = spi.xfer2([1, (8 + channel) << 4, 0])
    _select_cs(low=False)
    value = ((adc[1] & 3) << 8) | adc[2]
    return value

def set_direction_leds(up=False, down=False, left=False, right=False):
    GPIO.output(LED_UP, GPIO.HIGH if up else GPIO.LOW)
    GPIO.output(LED_DOWN, GPIO.HIGH if down else GPIO.LOW)
    GPIO.output(LED_LEFT, GPIO.HIGH if left else GPIO.LOW)
    GPIO.output(LED_RIGHT, GPIO.HIGH if right else GPIO.LOW)

def lcd_update(x, y, locked):
    if not has_lcd or lcd is None:
        return
    try:
        lcd.clear()
        lcd.cursor_pos = (0, 0)
        lcd.write_string(f'X:{x:4d} Y:{y:4d}')
        lcd.cursor_pos = (1, 0)
        lcd.write_string('LOCKED' if locked else 'UNLOCKED')
    except Exception as e:
        # on LCD error, disable further LCD usage
        print('LCD error:', e)
        global has_lcd, lcd
        has_lcd = False
        lcd = None

def main():
    global unlocked
    try:
        while True:
            x = read_mcp3008_channel(0)
            y = read_mcp3008_channel(1)
            sw_val = GPIO.input(SW_PIN)
            if sw_val == False:
                time.sleep(DEBOUNCE_DELAY)
                if GPIO.input(SW_PIN) == False:
                    unlocked = not unlocked
                    GPIO.output(LED_RED, GPIO.LOW if unlocked else GPIO.HIGH)
                    GPIO.output(LED_GREEN, GPIO.HIGH if unlocked else GPIO.LOW)
                    if not unlocked:
                        set_direction_leds(False, False, False, False)
                    time.sleep(0.25)
            if unlocked:
                set_direction_leds(False, False, False, False)
                if x < CENTER_LOW:
                    GPIO.output(LED_LEFT, GPIO.HIGH)
                elif x > CENTER_HIGH:
                    GPIO.output(LED_RIGHT, GPIO.HIGH)
                if y < CENTER_LOW:
                    GPIO.output(LED_UP, GPIO.HIGH)
                elif y > CENTER_HIGH:
                    GPIO.output(LED_DOWN, GPIO.HIGH)
            # update LCD each loop
            lcd_update(x, y, not GPIO.input(LED_RED))
            # print to console for debugging
            print(f'X={x:4d} Y={y:4d} LOCKED={not unlocked}')
            time.sleep(LOOP_DELAY)
    except KeyboardInterrupt:
        print('Exiting...')
    finally:
        if lcd is not None:
            try:
                lcd.clear()
            except Exception:
                pass
        spi.close()
        GPIO.cleanup()

if __name__ == '__main__':
    main()
