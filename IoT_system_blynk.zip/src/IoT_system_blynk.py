#!/usr/bin/env python3
"""
IoT System with Blynk - Herakica (2025)

Features:
- 4 LEDs controlled via Blynk Virtual Pins V0-V3
- DHT11 temperature & humidity sensor (V4 temperature, V5 humidity)
- HC-SR04 ultrasonic distance (V6 distance)
- Servo motor that actuates based on distance (V7 servo state)
- Optional I2C 16x2 LCD display (if I2C_LCD_driver installed)
"""

import time
import Adafruit_DHT
import BlynkLib
from gpiozero import AngularServo
import RPi.GPIO as GPIO

# Optional LCD import (safe)
try:
    import I2C_LCD_driver
    lcd = I2C_LCD_driver.lcd()
    has_lcd = True
except Exception:
    lcd = None
    has_lcd = False

# ---------- Configuration ----------
BLYNK_AUTH_TOKEN = "TOKEN123"  # Replace with your token!

# GPIO pins (BCM)
LED_PINS = [19, 26, 20, 21]    # V0, V1, V2, V3
SERVO_PIN = 24                 # Servo signal
DHT_PIN = 17                   # DHT11 data pin
PIN_TRIGGER = 5                # HC-SR04 trigger
PIN_ECHO = 6                   # HC-SR04 echo

# Servo pulse widths (seconds)
MIN_PW = 0.0005
MAX_PW = 0.0025

# Ultrasonic timeout (seconds)
ULTRASONIC_TIMEOUT = 0.02

# Distance thresholds (cm)
DIST_OPEN = 60.0

# ------------ Setup --------------
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# Setup LEDs
for pin in LED_PINS:
    GPIO.setup(pin, GPIO.OUT, initial=GPIO.LOW)

# Setup servo (using gpiozero.AngularServo)
servo = AngularServo(
    SERVO_PIN,
    initial_angle=0,
    min_angle=0,
    max_angle=180,
    min_pulse_width=MIN_PW,
    max_pulse_width=MAX_PW,
)

# DHT sensor type
DHT_SENSOR = Adafruit_DHT.DHT11

# Ultrasonic pins
GPIO.setup(PIN_TRIGGER, GPIO.OUT, initial=GPIO.LOW)
GPIO.setup(PIN_ECHO, GPIO.IN)

# ---------- Blynk ----------
blynk = BlynkLib.Blynk(BLYNK_AUTH_TOKEN)

@blynk.on("connected")
def blynk_connected():
    print("Connected to Blynk")

def make_led_handler(pin):
    def handler(value):
        try:
            state = int(value[0])
        except Exception:
            state = 0
        GPIO.output(pin, GPIO.HIGH if state else GPIO.LOW)
        print(f"LED {pin} -> {'ON' if state else 'OFF'} (via Blynk)")
    return handler

# Register handlers for V0..V3
for vpin, pin in zip(["V0","V1","V2","V3"], LED_PINS):
    blynk.on(vpin)(make_led_handler(pin))

# ---------- Utilities ----------
def measure_distance(timeout=ULTRASONIC_TIMEOUT):
    """
    Measure distance using HC-SR04.
    Returns distance in cm (float) or None if measurement failed.
    """
    # Send trigger (10 µs pulse)
    GPIO.output(PIN_TRIGGER, True)
    time.sleep(0.00001)  # 10 microseconds
    GPIO.output(PIN_TRIGGER, False)

    start_time = time.time()
    pulse_start = pulse_end = None

    # Wait for echo high with timeout
    while GPIO.input(PIN_ECHO) == 0 and (time.time() - start_time) < timeout:
        pulse_start = time.time()
    while GPIO.input(PIN_ECHO) == 1 and (time.time() - start_time) < timeout:
        pulse_end = time.time()

    if pulse_start is None or pulse_end is None:
        return None

    pulse_duration = pulse_end - pulse_start
    distance_cm = pulse_duration * 17150  # speed factor
    return round(distance_cm, 2)

# ---------- Main loop ----------
def main():
    try:
        while True:
            # Measure distance
            dist = measure_distance()
            if dist is not None:
                print(f"Distance: {dist:.2f} cm")
                blynk.virtual_write(6, dist)
                if has_lcd:
                    try:
                        lcd.lcd_clear()
                        lcd.lcd_display_string(f"Dist:{dist:.1f}cm", 1, 0)
                    except Exception as e:
                        print("LCD write error:", e)

                # Servo control with hysteresis using single branch logic
                if dist < DIST_OPEN:
                    servo.angle = 180
                    blynk.virtual_write(7, 1)
                else:
                    servo.angle = 0
                    blynk.virtual_write(7, 0)

            # Read DHT11
            humidity, temperature = Adafruit_DHT.read(DHT_SENSOR, DHT_PIN)
            if humidity is not None and temperature is not None:
                print(f"Temp={temperature:.1f}C Humidity={humidity:.1f}%")
                blynk.virtual_write(4, temperature)
                blynk.virtual_write(5, humidity)
                if has_lcd:
                    try:
                        lcd.lcd_display_string(f"T:{temperature:.1f}C H:{humidity:.1f}%", 2, 0)
                    except Exception as e:
                        print("LCD write error:", e)

            # Let Blynk process events and sleep briefly
            blynk.run()
            time.sleep(1)

    except KeyboardInterrupt:
        print("\nStopping (KeyboardInterrupt).")

    finally:
        # Final LCD cleanup if present
        if has_lcd:
            try:
                lcd.lcd_clear()
                lcd.lcd_display_string("System stopped", 1)
            except Exception:
                pass
        GPIO.cleanup()

if __name__ == "__main__":
    main()
