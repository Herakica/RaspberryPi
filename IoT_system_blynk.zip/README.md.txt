# IoT_system_blynk

**Author:** Herakica  
**Year:** 2025

Small IoT project for Raspberry Pi that integrates:
- Blynk cloud control (virtual pins)
- DHT11 temperature & humidity sensor
- HC-SR04 ultrasonic distance sensor
- Servo motor actuation
- I2C 16×2 LCD display (optional)
- 4 remote LEDs

## Quick start

1. Enable I2C and SPI on your Pi: 
	sudo raspi-config

Interface Options → enable I2C (and SPI if needed).

2. Install system packages and Python libs:
	sudo apt update
	sudo apt install -y python3-pip python3-rpi.gpio i2c-tools
	pip3 install -r requirements.txt

3. Wire the sensors and actuators (see WIRING.md).

4. Edit `src/smart_env_blynk.py` if you want to change the Blynk token:
- Replace `BLYNK_AUTH_TOKEN` with your token.

5. Run:
	chmod +x run.sh
	./run.sh


## Blynk mapping (recommended)
- V0 → LED 1 (GPIO 19)
- V1 → LED 2 (GPIO 26)
- V2 → LED 3 (GPIO 20)
- V3 → LED 4 (GPIO 21)
- V4 → Temperature (display only)
- V5 → Humidity (display only)
- V6 → Distance (display only)
- V7 → Servo state (0 or 1)

## Troubleshooting
- If the LCD doesn't show, check `i2cdetect -y 1` for address and ensure `I2C_LCD_driver` matches your module.
- If DHT11 reads `None`, try wiring and power, or swap to DHT22 if you have one.
- If the servo jitters, use an external 5V supply and common ground.

## License
MIT © 2025 Herakica


