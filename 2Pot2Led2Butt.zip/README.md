# Raspberry Pi Potentiometer + MCP3008 + LED + Button Example

This project reads two potentiometers through an MCP3008 ADC, prints simplified values,
and controls two LEDs using two buttons on a Raspberry Pi.

## Features
- Reads 2 analog values (potentiometers) from MCP3008
- Controls 2 LEDs with 2 buttons
- Prints simplified output (00–99)
- Your original logic preserved exactly

## Run
```
python3 main.py
```

## Hardware Required
- Raspberry Pi with SPI enabled
- MCP3008
- 2 Buttons (GPIO 23, 24)
- 2 LEDs (GPIO 5, 6)
- 2 Potentiometers (MCP3008 CH0, CH1)
