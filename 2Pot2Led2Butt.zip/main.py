import spidev
import time
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

#Open SPI bus
spi = spidev.SpiDev()
spi.open(0,0)
spi.max_speed_hz=1000000

#this is done so we can use dozens of SPI devices on 1 bus
CS_ADC = 22
GPIO.setup(CS_ADC, GPIO.OUT)

# Function to read SPI data from MCP3008 chip
# Channel must be an integer 0-7
def ReadChannel3008(channel):
    GPIO.output(CS_ADC, GPIO.LOW)
  #below sends 00000001 1xxx0000 00000000 to the chip and records the response
  #xxx encodes 0-7, the channel selected for the transfer.
    adc = spi.xfer2([1,(8+channel)<<4,0])
    data = ((adc[1]&3) << 8) + adc[2]
    GPIO.output(CS_ADC, GPIO.HIGH)
    return data

def ConvertToVoltage(value, bitdepth, vref):
  return vref*(value/(2**bitdepth-1))

delay = 0.1 # Define delay between readings

led1=5
led2=6
button1=23
button2=24


GPIO.setup(led1,GPIO.OUT)
GPIO.setup(button1, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(led2,GPIO.OUT)
GPIO.setup(button2, GPIO.IN, pull_up_down=GPIO.PUD_UP)

GPIO.output(led1,GPIO.LOW)

GPIO.output(led2,GPIO.LOW)

try:
  while True:
    if GPIO.input(button2)==True: #tipkalo nije pritisnuto
       GPIO.output(led1, GPIO.LOW)
    else:
        GPIO.output(led1, GPIO.HIGH)
    if GPIO.input(button1)==True: #tipkalo nije pritisnuto
       GPIO.output(led2, GPIO.LOW)
    else:
        GPIO.output(led2, GPIO.HIGH)
    GPIO.output(CS_ADC, GPIO.LOW)
    pot1 = ReadChannel3008(0)
    GPIO.output(CS_ADC, GPIO.HIGH)
    GPIO.output(CS_ADC, GPIO.LOW)
    pot2 = ReadChannel3008(1)
    GPIO.output(CS_ADC, GPIO.HIGH)
    kombinacija1=pot1/100
    kombinacija2=pot2/100

    print(f"{int(kombinacija1)}{int(kombinacija2)}")   

except KeyboardInterrupt:
    GPIO.cleanup()
